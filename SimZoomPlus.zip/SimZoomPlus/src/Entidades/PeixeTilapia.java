package Entidades;

public class PeixeTilapia extends Animal {

    @Override
    public void imprimir() {
        System.out.println("Sou um Peixe Tilápia");
        setIdentificador(58);
        setNome("Pingo");
        setCor("Verde");
        setSexo('f');
        setDescricao("A Tilápia é um peixe de escamas, com corpo um pouco \n"
                + "alto e comprimido. Possui coloração verde-oliva prateada, \n"
                + "com sobras verticais negras. A cor da nadadeira dorsal \n"
                + "também é verde-oliva, com uma linha vermelha e branca \n"
                + "até cinza-escuro com pontos oblíquos.");
        System.out.println("Identificador: " + getIdentificador());
        System.out.println("Meu nome é: " + getNome());
        System.out.println("Minha cor é: " + getCor());
        System.out.println("Sexo: " + getSexo());
        System.out.println("Minha breve Descrição: " + getDescricao());
        System.out.println("MEUS COMPORTAMENTOS SÃO: ");
        funcaoEmitirSom = new EmitirSomPeixe();
        funcaoEmitirSom.emitirSom();
        funcaoNadar = new FuncaoNadando();
        funcaoNadar.nadar();
        funcaoAlimentar = new AlimentacaoOnivora();
        funcaoAlimentar.alimentar();
    }

}
