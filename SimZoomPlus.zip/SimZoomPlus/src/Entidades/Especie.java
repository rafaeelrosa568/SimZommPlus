
package Entidades;

import lombok.*;

@Getter
@Setter

public abstract class Especie extends Animal {
    
    private int id;
    private String descricao;
 
    
    
    
    
}
