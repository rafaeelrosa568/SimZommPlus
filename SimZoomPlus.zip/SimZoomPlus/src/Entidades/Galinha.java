package Entidades;

public class Galinha extends Animal {

    @Override
    public void imprimir() {
        System.out.println("Sou uma galinha");
        setIdentificador(26);
        setNome("Carijó");
        setCor("Branca");
        setSexo('f');
        setDescricao("tenho um pequeno pente em forma de V, "
                + "\nembora muitas vezes esteja oculto por uma grande "
                + "\ncrista de penas. Os lóbulos das orelhas e barbelas "
                + "\nsão pequenos e também podem estar completamente "
                + "\nescondidos pela crista e pela barba. ");

        System.out.println("Identificação: " + getIdentificador());
        System.out.println("Meu nome é: " + getNome());
        System.out.println("Minha cor é: " + getCor());
        System.out.println("Sou do sexo: " + getSexo());
        System.out.println("");

        System.out.println("Minha breve descrição: " + getDescricao());
        System.out.println("MEUS COMPORTAMENTOS SÃO");
        funcaoEmitirSom = new EmitirSomCacarejar();
        funcaoEmitirSom.emitirSom();
        funcaoVoar = new FuncaoVoando();
        funcaoVoar.voar();
        funcaoAlimentar = new AlimentacaoGranivoros();
        funcaoAlimentar.alimentar();
        funcaoAndar = new FuncaoAndandoCom2patas();
        funcaoAndar.andar();

    }

}
