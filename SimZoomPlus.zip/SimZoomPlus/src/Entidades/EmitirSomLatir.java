package Entidades;


public class EmitirSomLatir implements InterfaceFuncaoEmitirSom {

    
    @Override
    public void emitirSom() {
        System.out.println("Eu emito o som: \n Auu!! Auu!! Auu!!");
    }

    
}
