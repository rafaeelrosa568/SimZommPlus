
package Entidades;

public class EmitirSomRugir implements InterfaceFuncaoEmitirSom {
    
    @Override
    public void emitirSom() {
        System.out.println("EU EMITO O SOM: Roar!! Grraurrr! Brrrum!");
    }


    
}
