package Entidades;

import java.util.Calendar;

public class Onca extends Animal {

    @Override
    public void imprimir() {
        System.out.println("Sou uma Onça");
        setIdentificador(55);
        setNome("Paulo");
        setCor("Minha cor é: Parda");
        setSexo('m');
        especie = new EspecieMamiferos();
        especie.tipoDeAnimal();
        setDataNascimento(Calendar.getInstance());
        setDescricao("O nome científico da onça-parda é Puma concolor.  \n"
                + "A onça-parda é carnívora e se alimenta, principalmente, \n"
                + "de pequenos mamíferos, aves e roedores de pequeno porte. \n"
                + "Em seu habitat natural e preservado, os animais desta \n"
                + "espécie vivem, em média, 20 anos.");
        System.out.println("Identificador: " + getIdentificador());
        System.out.println("Meu nome é: " + getNome());
        System.out.println(getCor());
        System.out.println("Sexo: " + getSexo());
        System.out.println("Minha breve Descrição: " + getDescricao());
        System.out.println("MEUS COMPORTAMENTOS SÃO: ");
        funcaoEmitirSom = new EmitirSomRugir();
        funcaoEmitirSom.emitirSom();
        funcaoAndar = new FuncaoAndandoCom4patas();
        funcaoAndar.andar();
        funcaoAlimentar = new AlimentacaoCarnivoro();
        funcaoAlimentar.alimentar();
    }

}
