
package Entidades;


public class EmitirSomCacarejar implements InterfaceFuncaoEmitirSom {

    @Override
    public void emitirSom() {
        System.out.println("Eu emito o som: Cocó!! Cocó!! Cocó!!");
    }
    
    
}
