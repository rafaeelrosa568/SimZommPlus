
package Entidades;


public class EspecieMamiferos implements InterfaceEspecie {


    @Override
    public void tipoDeAnimal() {
    System.out.println("Sou Mamíferos");    
    
    }
    
    public void especieRacaLabradorBranco(){
        System.out.println("Sou um cachorro da raça labrador branco");
    }
    
    
}
