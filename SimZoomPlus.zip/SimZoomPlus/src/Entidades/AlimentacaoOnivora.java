
package Entidades;


public class AlimentacaoOnivora implements InterfaceFuncaoAlimentar{

    @Override
    public void alimentar() {
        System.out.println("Alimentação: Onívora"
                + "algas, frutos, sementes, \n"
                + "larvas e ninfas de \n"
                + "insetos, moluscos, peixes, entre outros");    
    
    }
    
}
