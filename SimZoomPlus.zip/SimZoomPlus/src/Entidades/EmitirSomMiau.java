
package Entidades;

public class EmitirSomMiau implements InterfaceFuncaoEmitirSom{

    @Override
    public void emitirSom() {
        System.out.println("Eu emito so som: Miau !! Miau !!!");
    }


    
}
