package Entidades;

public class Cavalo extends Animal {

    @Override
    public void imprimir() {
        System.out.println("Sou um cavalo");
        setIdentificador(25);
        setNome("Freed");
        setCor("Marrom");
        setSexo('M');
        especie = new EspecieMamiferos();
        especie.tipoDeAnimal();
        setDescricao("O Cavalo da raça  marrom que apresenta o corpo mais escuro, "
                + "\ncrina, cauda e pontas puxadas para preto");
        System.out.println("Identificador: " + getIdentificador());
        System.out.println("Sexo: " + getSexo());
        System.out.println("Meu nome é: " + getNome());
        System.out.println("Minha cor é: " + getCor());
        System.out.println("Sou do sexo: " + getSexo());

        System.out.println("Minha breve descrição: " + getDescricao());
        System.out.println("Meus comportamentos são: ");

        funcaoEmitirSom = new EmitirSomRelinchar();
        funcaoEmitirSom.emitirSom();
        funcaoAndar = new FuncaoAndandoCom4patas();
        funcaoAndar.andar();
        funcaoAlimentar = new AlimentacaoHerbivoro();
        funcaoAlimentar.alimentar();

    }

}
