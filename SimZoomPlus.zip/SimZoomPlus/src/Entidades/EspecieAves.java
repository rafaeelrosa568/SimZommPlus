
package Entidades;


public class EspecieAves implements InterfaceEspecie{

    @Override
    public void tipoDeAnimal() {
        System.out.println("Sou uma especie de Aves");    
    
    }
    
    public void galinhaPolonesa(){
        System.out.println("tem um pequeno pente em forma de V, "
                + "\nembora muitas vezes esteja oculto por uma grande "
                + "\ncrista de penas. Os lóbulos das orelhas e barbelas "
                + "\nsão pequenos e também podem estar completamente "
                + "\nescondidos pela crista e pela barba. ");
    }
    
}
