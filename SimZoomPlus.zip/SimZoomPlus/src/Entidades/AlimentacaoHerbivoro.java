
package Entidades;


public class AlimentacaoHerbivoro implements InterfaceFuncaoAlimentar{

    @Override
    public void alimentar() {
        System.out.println("Comer: Vegetais");
    }


    
}
