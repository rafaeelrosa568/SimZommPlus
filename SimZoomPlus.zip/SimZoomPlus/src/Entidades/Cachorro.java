package Entidades;

public class Cachorro extends Animal {

    @Override
    public void imprimir() {
        System.out.println("Sou um cachorro");
        System.out.println("Sou da raça labrador");
        setIdentificador(20);
        setNome("MAX");
        setCor("Preto");
        setSexo('m');
        especie = new EspecieMamiferos();
        especie.tipoDeAnimal();
        especie = new EspecieMamiferos();
        especie.tipoDeAnimal();
        setDescricao("MAX é da raça labrador, São cães obedientes, "
                + "\nfiéis e de excelentes faro e agilidade "
                + "\nAlém do temperamento, sua aparência também é encantadora! "
                + "\nO Labrador chocolate é muito conhecido, "
                + "\nmas a raça também pode ter cores amarelo e preto. "
                + "\nSeus olhos demonstram que estão realmente "
                + "\nsempre atentos e ativos.");

        System.out.println("Identificador: " + getIdentificador());
        System.out.println("Meu nome é: " + getNome());
        System.out.println("Minha cor é: " + getCor());
        System.out.println("sexo: " + getSexo());
        System.out.println("Minha breve descrição: " + getDescricao());
        System.out.println("Meus comportamentos são: ");
        funcaoEmitirSom = new EmitirSomLatir();
        funcaoEmitirSom.emitirSom();
        funcaoAlimentar = new AlimentacaoCarnivoro();
        funcaoAlimentar.alimentar();
        funcaoAndar = new FuncaoAndandoCom4patas();
        funcaoAndar.andar();
    }

}
