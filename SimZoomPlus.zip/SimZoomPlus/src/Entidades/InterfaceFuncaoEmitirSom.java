package Entidades;


public interface InterfaceFuncaoEmitirSom {
    
    public void emitirSom();
    
}
