
package Entidades;


public interface InterfaceFuncaoNadar {
    
    public void nadar();
    
}
