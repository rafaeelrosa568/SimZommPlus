
package Entidades;

public interface InterfaceEspecie {
    
    public void tipoDeAnimal();
}
