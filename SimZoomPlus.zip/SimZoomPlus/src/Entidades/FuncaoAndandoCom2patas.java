
package Entidades;


public class FuncaoAndandoCom2patas implements InterfaceFuncaoAndar{

    
    @Override
    public void andar(){
        System.out.println("Andar com 2 patas");
    }
    
}
