
package Entidades;


public interface InterfaceFuncaoAlimentar {

    public void alimentar();
    
}
