package Entidades;

public class Gato extends Animal {

    @Override
    public void imprimir() {
        System.out.println("Sou um gato");
        setIdentificador(28);
        setNome("Flash");
        setCor("preto");
        setSexo('f');
        especie = new EspecieMamiferos();
        especie.tipoDeAnimal();
        setDescricao("O gato preto Persa chama a atenção por conta dos "
                + "\npelos longos e do focinho achatado. "
                + "\nSão gatinhos sossegados e com temperamento dócil. "
                + "\nO que mais gostam de fazer é ficar quietos "
                + "\nno cantinho deles.");
        System.out.println("Identificador: " + getIdentificador());
        System.out.println("meu nome é: " + getNome());
        System.out.println("Minha cor é: " + getCor());
        System.out.println("Sexo: " + getSexo());
        System.out.println("Minha breve descrição: " + getDescricao());
        System.out.println("MEUS COMPORTAMENTOS SÃO:");
        funcaoEmitirSom = new EmitirSomMiau();
        funcaoEmitirSom.emitirSom();
        funcaoAndar = new FuncaoAndandoCom4patas();
        funcaoAndar.andar();
        funcaoAlimentar = new AlimentacaoCarnivoro();
        funcaoAlimentar.alimentar();

    }

}
