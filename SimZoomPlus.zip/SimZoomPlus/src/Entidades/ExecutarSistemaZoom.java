package Entidades;

public class ExecutarSistemaZoom {

    public static void main(String[] args) {

        Cachorro Max = new Cachorro();
        Max.imprimir();

        System.out.println("========================================");

        Galinha Carijo = new Galinha();
        Carijo.imprimir();

        System.out.println("========================================");

        Leao Simba = new Leao();
        Simba.imprimir();

        System.out.println("=========================================");

        Gato Flash = new Gato();
        Flash.imprimir();

        System.out.println("===========================================");

        Onca Black = new Onca();
        Black.imprimir();

        System.out.println("===========================================");

        Cavalo Freed = new Cavalo();
        Freed.imprimir();
        
        System.out.println("===========================================");

        PeixeTilapia Pingo = new PeixeTilapia();
        Pingo.imprimir();
    }

}
