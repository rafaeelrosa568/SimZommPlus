
package Entidades;


public class AlimentacaoGranivoros implements InterfaceFuncaoAlimentar {

    @Override
    public void alimentar() {
        System.out.println("Comer: Grãos ");
    }
    


    
}
