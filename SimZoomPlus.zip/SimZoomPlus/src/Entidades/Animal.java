package Entidades;

import java.util.Calendar;
import Entidades.DataUtility;
import java.util.Date;
import lombok.*;

@Getter
@Setter

public abstract class Animal {

private String nome;
private String cor;
private String descricao;
private int identificador;
private char sexo;
Calendar dataNascimento;
InterfaceEspecie especie;
InterfaceFuncaoEmitirSom funcaoEmitirSom;
InterfaceFuncaoAndar funcaoAndar;
InterfaceFuncaoVoar funcaoVoar;
InterfaceFuncaoNadar funcaoNadar;
InterfaceFuncaoAlimentar funcaoAlimentar;

public abstract void imprimir();


public int calcularIdade(Date dataNascimento) {
   return  DataUtility.calcularIdade(dataNascimento);
   
    
}


}
