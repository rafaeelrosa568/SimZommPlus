
package Entidades;

public class AlimentacaoCarnivoro implements InterfaceFuncaoAlimentar {

    @Override
    public void alimentar() {
        System.out.println("Minha alimentação: Carnívoro");
    }
    
    
    
}
