
package Entidades;


public class FuncaoAndandoCom4patas implements InterfaceFuncaoAndar {

    @Override
    public void andar() {
        System.out.println("Andar com quatro patas.");
        
    }
    


    
}
