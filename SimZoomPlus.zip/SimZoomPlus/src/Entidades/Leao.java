
package Entidades;

public class Leao extends Animal {
    
    @Override
    public void imprimir(){
        setIdentificador(40);
        System.out.println("Sou um leão");
        setNome("Simbá");
        setCor("Amarelo");
        setSexo('m');
        especie = new EspecieMamiferos();
        especie.tipoDeAnimal();
        setDescricao("Simba é o herdeiro do grande leão rei dos animais, \n"
                + "Mufasa. Em sua infância, comportava-se de \n"
                + "forma inconsequente e arrogante. \n"
                + "Sempre se deixava guiar por seu espírito curioso e \n"
                + "aventureiro, desrespeitando os limites impostos pelos pais,\n"
                + "o que lhe rendia muitas encrencas.");
        setEspecie(especie);
        
        System.out.println("Identificador: " + getIdentificador());
        System.out.println("Meu nome é: " + getNome());
        System.out.println("Minha cor é: "+ getCor());
        System.out.println("Sexo: " + getSexo());
        System.out.println("Breve Descrição: " + getDescricao());
        System.out.println("Especie: " + getEspecie());
        System.out.println("MEUS COMPORTAMENTOS SÃO");
        funcaoEmitirSom = new EmitirSomRugir();
        funcaoEmitirSom.emitirSom();
        funcaoAndar = new FuncaoAndandoCom4patas();
        funcaoAndar.andar();
        funcaoAlimentar = new AlimentacaoCarnivoro();
        funcaoAlimentar.alimentar();
    }

    
}
