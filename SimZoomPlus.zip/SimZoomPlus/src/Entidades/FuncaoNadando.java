
package Entidades;


public class FuncaoNadando implements InterfaceFuncaoNadar{

    @Override
    public void nadar() {
        System.out.println("Nadando com as nadadeiras e caudas");    
    
    }
    
}
