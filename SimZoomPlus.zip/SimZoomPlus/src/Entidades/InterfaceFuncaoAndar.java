package Entidades;


public interface InterfaceFuncaoAndar {

    public void andar();
    
    
}
