
package Entidades;

public class FuncaoVoando implements InterfaceFuncaoVoar {

    @Override
    public void voar(){
        System.out.println("Voar com duas asas");
    }

    
}
