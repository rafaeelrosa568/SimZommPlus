
package Entidades;

public interface InterfaceFuncaoVoar {

    public void voar();
    
}
