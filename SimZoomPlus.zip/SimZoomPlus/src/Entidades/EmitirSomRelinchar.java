
package Entidades;


public class EmitirSomRelinchar implements InterfaceFuncaoEmitirSom {

    @Override
    public void emitirSom(){
        System.out.println("Eu emito o som: "
                + "\n hinn in in !! hinn in in !! hinn in in !!");
}

    
}
