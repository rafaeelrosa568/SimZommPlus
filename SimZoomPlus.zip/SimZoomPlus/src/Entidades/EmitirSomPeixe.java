
package Entidades;


public class EmitirSomPeixe implements InterfaceFuncaoEmitirSom{

    @Override
    public void emitirSom() {
        System.out.println("Eu amito o som:"
                + "glub glub! glub glub!");    
    
    }
    
}
