package Entidades;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

public abstract class DataUtility {
    
    public static SimpleDateFormat formatoPadrao
            = new SimpleDateFormat("dd/MM/yyyy");

    /**
     * Método verifica se a data informada é menor que a data de hoje
     *
     * @param dataInformada
     * @return
     */
    public static boolean isDataMaiorQueHoje(Date dataInformada) {
        
        return dataInformada.after(new Date());
        
    }
    
    public static boolean isDataMenorQueHoje(Date dataInformada) {
        
        return dataInformada.before(new Date());
        
    }

    /**
     * Transforma um texto digitado( String ) para um valor de data.
     *
     * @param dataInformada
     * @return
     */
    //Não esquecer de colocar o método static ( Exemplo: public statci Date Transformar.....)
    public static Date transformarStringEmDate(String dataInformada) {

        /*Caso fique demonstrando algum erro, será necessário fazer um try-catch
        e apagar todo o código que o catch coloca, e colocar um sout(ex).
         */
        Date dataParse = null;
        try {
            
            dataParse = formatoPadrao.parse(dataInformada);
        } catch (ParseException ex) {
            System.out.println(ex);
        }
        return dataParse;
    }

    //Eu não posso retornar nulo em tipos primitivos (boolean)
    public static boolean isDataInformadaHoje(Date dataInformada) {
        
        return dataInformada.equals(new Date());
    }
    
    public static String formatarDataComPadrao(Date dataInformada, String padrao) {
        
        String dataFormatada = null;
        
        if (dataInformada == null || padrao == null) {
            
            return null;
        }
        
        formatoPadrao.applyPattern(padrao);
        dataFormatada = formatoPadrao.format(dataInformada);
        formatoPadrao.applyPattern("dd/MM/yyyy");
        return dataFormatada;
    }
    
    /**
     * Método que transforma um objeto do tipo Date em um objeto LocalDate
     * 
     * @param data
     * @return 
     */
    public static LocalDate dataParaLocalDate (Date data){
        
        return data.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    }
    
    public static int calcularIdade(Date dataNascimento){
        
        LocalDate hoje = LocalDate.now();
        Period periodo = Period.between(dataParaLocalDate(dataNascimento), hoje);
        
        return periodo.getYears();
        
    }
    
    /**
     * Retorna o dia da semana que vai cair a data
     * 
     * @param data Date
     * @return Integer Calendar.DAY_OF_WEEK
     */
    public static Integer retornarDiaDaSemana(Date data) {
        Calendar calendario = Calendar.getInstance();
        calendario.setTime(data);
        return calendario.get(Calendar.DAY_OF_WEEK);
    }
    
    
    /**
     * Verifica se a data é Sexta, Sábado ou Domingo.
     * 
     * @param data A data.
     * @return Verdadeiro se for Sexta, Sábado ou Domingo.
     */
    
    public static boolean isSextaSabadoDomingo(Date data) {
        Integer diaSemana = retornarDiaDaSemana(data);
        if (diaSemana == Calendar.FRIDAY || diaSemana == Calendar.SATURDAY 
                || diaSemana == Calendar.SUNDAY) {
            return true;
        }
        
        return false;
    }
}
